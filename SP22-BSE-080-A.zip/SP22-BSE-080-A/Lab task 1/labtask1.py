num = input("Enter an integer: ")

reversed_num = num[::-1]

print(f"The reversed number is: {reversed_num}")